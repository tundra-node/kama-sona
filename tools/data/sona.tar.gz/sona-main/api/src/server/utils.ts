import { zValidator } from "@hono/zod-validator";
import { z } from "zod/v4";
import type { Languages as LangsV1 } from "../lib/v1";
import type { Languages as LangsV2 } from "../lib/v2";

export const entries = <const T extends object>(
  o: T,
): {
  [K in keyof T]: [K, T[K]];
}[keyof T][] => {
  return Object.entries(o) as [keyof T, T[keyof T]][];
};

export const keys = <const K extends PropertyKey>(o: Record<K, any>): K[] => {
  return Object.keys(o) as K[];
};

export const filterObject = <const T extends object>(
  o: T,
  predicate: (o: [keyof T, T[keyof T]]) => boolean,
) => {
  return Object.fromEntries(entries(o).filter(([key, value]) => predicate([key, value])));
};

export const langIdCoalesce = (lang: string, langs: LangsV1 | LangsV2): string | undefined => {
  //  lang is the langcode
  if (lang in langs) {
    return lang;
  }

  for (const [id, metadata] of Object.entries(langs)) {
    // lang is the locale e.g. ca-ES, fr-FR, zh-CN
    if (lang === metadata.locale) {
      return id;
    }

    for (const [_, name] of Object.entries(metadata.name)) {
      if (lang.toLowerCase() === name?.toLowerCase()) {
        return id;
      }
    }
  }

  return undefined;
};

export const langValidator = zValidator(
  "query",
  z.object({
    lang: z
      .string()
      .regex(/^([^,]+,)*[^,]+/)
      .optional(),
  }),
);

export function joinPath(...segments: string[]) {
  return segments
    .filter(Boolean)
    .join("/")
    .replace(/\/{2,}/g, "/")
    .replace(/^\/+/, "")
    .replace(/\/+$/, "");
}

export function mergeToKey<
  T extends Record<PropertyKey, any>,
  K extends PropertyKey,
  S extends Record<PropertyKey, any>[],
>(target: T, tkey: K, ...sources: S) {
  if (!sources.length) {
    return target;
  }
  const source = sources.shift();
  for (const key in source) {
    // no safety check for whether the key is on the target
    // zod will catch
    target[key][tkey] = source[key];
  }
  return target;
}
